#=====================================================================#
# This is code to create: RC-poll-data.R
# Authored by and feedback to:
# MIT License
# Version: 1.0
#=====================================================================#


library(tidyverse)
library(datapasta)
library(janitor)
# 2020 Democratic Presidential Nomination
# this came from this site on 2019-06-28
# https://www.realclearpolitics.com/epolls/2020/president/us/2020_democratic_presidential_nomination-6730.html#polls

# table names
# datapasta::vector_paste()
# table_names <- c(
#   "Poll", "Date", "Biden", "Sanders", "Warren", "Harris",
#   "Buttigieg", "ORourke", "Booker", "Yang", "Klobuchar",
#   "Gabbard", "Castro", "Ryan", "Bullock", "Gillibrand", "Spread"
# )
# noquote(paste0("~", table_names, collapse = ", "))
RCPollData <- tibble::tribble(
                         ~Poll,           ~Date, ~Biden, ~Sanders, ~Warren, ~Harris, ~Buttigieg, ~ORourke, ~Booker, ~Yang, ~Klobuchar, ~Gabbard, ~Castro, ~Ryan, ~Bullock, ~Gillibrand,      ~Spread,
            "Economist/YouGov",   "6/22.-.6/25",     25,       15,      19,       7,        "6",      "3",     "1",   "2",        "0",      "3",     "1",   "0",      "1",         "1",   "Biden.+6",
                     "Emerson",   "6/21 - 6/24",     34,       27,      14,       7,        "6",      "1",     "3",   "1",        "1",      "0",     "0",   "0",      "0",         "1",   "Biden +7",
    "Politico/Morning Consult",   "6/17 - 6/23",     38,       19,      13,       6,        "7",      "4",     "3",   "2",        "1",      "1",     "1",   "1",      "1",         "1",  "Biden +19",
            "Economist/YouGov",   "6/16 - 6/18",     26,       12,      16,       7,        "9",      "3",     "2",   "1",        "1",      "1",     "1",   "0",      "1",         "0",  "Biden +10",
                    "Monmouth",   "6/12 - 6/17",     32,       14,      15,       8,        "5",      "3",     "2",   "2",        "1",      "1",     "0",   "0",      "0",         "0",  "Biden +17",
            "The Hill/HarrisX",   "6/14 - 6/15",     35,       13,       7,       5,        "4",      "6",     "3",   "0",        "1",      "0",     "2",   "1",      "1",         "0",  "Biden +22",
    "Politico/Morning Consult",   "6/10 - 6/16",     38,       19,      11,       7,        "7",      "4",     "3",   "1",        "1",      "1",     "1",   "1",      "0",         "1",  "Biden +19",
           "USA Today/Suffolk",   "6/11 - 6/15",     30,       15,      10,       8,        "9",      "2",     "2",   "1",        "0",      "0",     "1",   "1",      "1",         "0",  "Biden +15",
                    "FOX News",    "6/9 - 6/12",     32,       13,       9,       8,        "8",      "4",     "3",   "2",        "2",      "1",     "1",   "1",      "0",         "1",  "Biden +19",
            "Economist/YouGov",    "6/9 - 6/11",     27,       12,      16,       7,        "8",      "3",     "2",   "1",        "0",      "0",     "1",   "0",      "0",         "1",  "Biden +11",
                  "Quinnipiac",    "6/6 - 6/10",     30,       19,      15,       7,        "8",      "3",     "1",   "1",        "1",      "0",     "0",   "1",      "0",         "0",  "Biden +11",
    "Politico/Morning Consult",     "6/3 - 6/9",     37,       19,      11,       7,        "7",      "4",     "3",   "1",        "2",      "1",     "1",   "1",      "1",         "1",  "Biden +18",
            "Economist/YouGov",     "6/2 - 6/4",     27,       15,      12,       9,       "10",      "2",     "2",   "1",        "1",      "1",     "0",   "0",      "1",         "0",  "Biden +12",
            "The Hill/HarrisX",     "6/1 - 6/2",     35,       16,       5,       4,        "8",      "4",     "3",   "0",        "1",      "0",     "0",   "0",      "0",         "0",  "Biden +19",
    "Politico/Morning Consult",    "5/27 - 6/2",     38,       19,      10,       7,        "7",      "4",     "3",   "1",        "1",      "1",     "1",   "1",      "1",         "1",  "Biden +19",
                         "CNN",   "5/28 - 5/31",     32,       18,       7,       8,        "5",      "5",     "3",   "1",        "2",      "1",     "2",   "1",      "0",         "1",  "Biden +14",
              "Harvard-Harris",   "5/29 - 5/30",     36,       17,       5,       8,        "5",      "4",     "3",   "1",        "0",      "0",     "1",   "1",       NA,         "0",  "Biden +19",
    "Politico/Morning Consult",   "5/20 - 5/26",     38,       20,       9,       7,        "7",      "4",     "3",   "1",        "1",      "1",     "1",   "1",      "1",         "1",  "Biden +18",
                    "Monmouth",   "5/16 - 5/20",     33,       15,      10,      11,        "6",      "4",     "1",   "1",        "3",      "1",     "1",   "0",      "0",         "0",  "Biden +18",
            "The Hill/HarrisX",   "5/17 - 5/18",     33,       14,       8,       6,        "6",      "5",     "1",   "1",        "1",      "0",     "1",   "1",      "0",         "1",  "Biden +19",
                  "Quinnipiac",   "5/16 - 5/20",     35,       16,      13,       8,        "5",      "2",     "3",   "1",        "2",      "1",     "1",   "0",      "0",         "0",  "Biden +19",
    "Politico/Morning Consult",   "5/13 - 5/20",     39,       19,       9,       8,        "6",      "4",     "3",   "1",        "1",      "1",     "1",   "1",      "1",         "1",  "Biden +20",
                    "FOX News",   "5/11 - 5/14",     35,       17,       9,       5,        "6",      "4",     "3",   "1",        "2",      "1",     "2",   "1",      "0",         "0",  "Biden +18",
                     "Emerson",   "5/10 - 5/13",     33,       25,      10,      10,        "8",      "3",     "1",   "1",        "1",      "1",     "2",   "0",       NA,         "2",   "Biden +8",
    "Politico/Morning Consult",    "5/6 - 5/12",     39,       19,       8,       8,        "6",      "5",     "3",   "1",        "2",      "1",     "1",   "1",      "0",         "1",  "Biden +20",
            "The Hill/HarrisX",     "5/3 - 5/4",     46,       14,       7,       6,        "8",      "3",     "3",   "1",        "0",      "1",     "1",   "1",       NA,         "1",  "Biden +32",
    "Politico/Morning Consult",    "4/29 - 5/5",     40,       19,       8,       7,        "6",      "5",     "3",   "1",        "2",      "1",     "1",   "1",      "1",         "1",  "Biden +21",
              "Harvard-Harris",    "4/30 - 5/1",     44,       14,       5,       9,        "2",      "3",     "3",   "0",        "2",      "0",     "0",   "1",       NA,         "0",  "Biden +30",
                  "Quinnipiac",   "4/26 - 4/29",     38,       11,      12,       8,       "10",      "5",     "2",   "1",        "1",      "0",     "1",   "0",       NA,         "0",  "Biden +26",
                         "CNN",   "4/25 - 4/28",     39,       15,       8,       5,        "7",      "6",     "2",   "1",        "2",      "2",     "1",   "0",      "0",         "1",  "Biden +24",
    "Politico/Morning Consult",   "4/22 - 4/28",     36,       22,       9,       7,        "8",      "5",     "3",   "2",        "2",      "1",     "1",   "1",      "1",         "1",  "Biden +14",
                    "Monmouth",   "4/11 - 4/15",     27,       20,       6,       8,        "8",      "4",     "2",   "0",        "1",      "0",     "0",   "0",      "0",         "0",   "Biden +7",
    "Politico/Morning Consult",   "4/15 - 4/21",     30,       24,       7,       8,        "9",      "6",     "4",   "2",        "2",      "1",     "1",   "1",      "0",         "1",   "Biden +6",
                     "Emerson",   "4/11 - 4/14",     24,       29,       7,       8,        "9",      "8",     "2",   "3",        "1",      "1",     "3",   "1",       NA,         "0", "Sanders +5",
    "Politico/Morning Consult",    "4/8 - 4/14",     31,       23,       7,       9,        "7",      "8",     "4",   "1",        "2",      "1",     "1",   "1",      "1",         "1",   "Biden +8",
    "Politico/Morning Consult",     "4/1 - 4/7",     32,       23,       7,       9,        "5",      "8",     "4",   "1",        "2",      "1",     "1",   "1",      "1",         "2",   "Biden +9",
            "The Hill/HarrisX",     "4/5 - 4/6",     36,       19,       6,       9,        "4",      "7",     "6",   "1",        "2",      "0",     "1",    NA,       NA,         "2",  "Biden +17",
    "Politico/Morning Consult",   "3/25 - 3/31",     33,       25,       7,       8,        "3",      "8",     "4",    NA,        "2",      "1",     "1",    NA,      "1",         "1",   "Biden +8",
                  "Quinnipiac",   "3/21 - 3/25",     29,       19,       4,       8,        "4",     "12",     "2",   "0",        "2",      "0",     "1",    NA,       NA,         "0",  "Biden +10",
              "Harvard-Harris",   "3/25 - 3/26",     35,       17,       6,       5,        "2",      "7",     "4",   "1",        "2",      "2",     "1",    NA,       NA,         "1",  "Biden +18",
              "Harvard-Harris",   "3/25 - 3/26",     26,       18,       5,      11,        "2",      "5",     "3",   "2",        "1",      "0",     "1",    NA,       NA,         "0",   "Biden +8",
    "Politico/Morning Consult",   "3/18 - 3/24",     35,       25,       7,       8,        "2",      "8",     "4",    NA,        "2",      "1",     "1",    NA,      "1",         "1",  "Biden +10",
                    "FOX News",   "3/17 - 3/20",     31,       23,       4,       8,        "1",      "8",     "4",   "1",        "1",      "0",     "1",    NA,      "0",         "2",   "Biden +8",
                     "Emerson",   "3/17 - 3/18",     26,       26,       8,      12,        "3",     "11",     "3",   "1",        "1",      "1",     "1",    NA,       NA,         "0",        "Tie",
                         "CNN",   "3/14 - 3/17",     28,       20,       6,      12,        "1",     "11",     "3",    NA,        "3",      "0",     "1",    NA,      "0",         "1",   "Biden +8",
    "Politico/Morning Consult",   "3/11 - 3/17",     35,       27,       7,       8,        "1",      "8",     "4",    NA,        "2",      "1",     "1",    NA,      "0",         "1",   "Biden +8",
    "Politico/Morning Consult",    "3/4 - 3/10",     31,       27,       7,      10,        "1",      "7",     "4",    NA,        "3",      "1",     "1",    NA,      "1",         "1",   "Biden +4",
                    "Monmouth",     "3/1 - 3/4",     28,       25,       8,      10,        "0",      "6",     "5",   "1",        "3",      "0",     "1",    NA,      "0",         "0",   "Biden +3",
    "Politico/Morning Consult",    "2/25 - 3/3",     31,       27,       7,      11,        "1",      "6",     "4",    NA,        "3",      "1",     "1",    NA,       NA,         "1",   "Biden +4",
              "Harvard-Harris",   "2/19 - 2/20",     37,       22,       4,      10,         NA,      "6",     "2",    NA,         NA,      "1",     "2",    NA,       NA,         "1",  "Biden +15",
              "Harvard-Harris",   "2/19 - 2/20",     30,       19,       4,      10,         NA,      "4",     "5",    NA,         NA,      "0",     "0",    NA,       NA,         "0",  "Biden +11",
    "Politico/Morning Consult",   "2/18 - 2/24",     29,       27,       7,      10,        "1",      "7",     "4",    NA,        "3",      "1",     "1",    NA,       NA,         "1",   "Biden +2",
    "Politico/Morning Consult",   "2/11 - 2/17",     30,       21,       8,      11,        "0",      "7",     "5",    NA,        "4",      "1",     "1",    NA,       NA,         "1",   "Biden +9",
                     "Emerson",   "2/14 - 2/16",     27,       17,       9,      15,        "0",      "4",     "9",    NA,        "5",      "2",     "1",    NA,       NA,         "1",  "Biden +10",
    "Politico/Morning Consult",    "2/4 - 2/10",     29,       22,       8,      13,         NA,      "7",     "5",    NA,        "3",      "1",     "1",    NA,       NA,         "1",   "Biden +7",
                    "Monmouth",   "1/25 - 1/27",     29,       16,       8,      11,        "0",      "7",     "4",    NA,        "2",      "1",     "1",    NA,       NA,         "1",  "Biden +13",
    "Politico/Morning Consult",   "1/25 - 1/27",     33,       15,       6,      10,         NA,      "6",     "3",    NA,        "1",      "0",     "1",    NA,       NA,         "1",  "Biden +18",
    "Politico/Morning Consult",   "1/18 - 1/22",     26,       16,       6,       9,         NA,      "6",     "4",    NA,        "2",       NA,     "2",    NA,       NA,         "2",  "Biden +10",
                    "Emerson*",   "1/20 - 1/21",     45,        5,       3,       3,         NA,      "3",     "8",    NA,        "1",      "2",     "8",    NA,       NA,         "1",  "Biden +37",
              "Harvard-Harris",   "1/15 - 1/16",     23,       21,       4,       7,         NA,      "8",     "3",    NA,         NA,      "2",     "1",    NA,       NA,         "2",   "Biden +2",
              "Harvard-Harris",   "1/15 - 1/16",     24,       13,       5,       4,         NA,      "9",     "2",    NA,         NA,      "1",     "2",    NA,       NA,         "1",  "Biden +11",
    "Politico/Morning Consult",   "1/11 - 1/14",     32,       15,       9,       6,         NA,      "8",     "2",    NA,        "1",       NA,     "0",    NA,       NA,         "1",  "Biden +17",
    "Politico/Morning Consult",     "1/4 - 1/6",     27,       16,       4,       3,         NA,      "7",     "3",    NA,        "2",       NA,     "0",    NA,       NA,         "1",  "Biden +11",
    "Politico/Morning Consult", "12/14 - 12/16",     25,       15,       3,       3,         NA,      "8",     "3",    NA,        "1",       NA,     "1",    NA,       NA,         "1",  "Biden +10",
                         "CNN",   "12/6 - 12/9",     30,       14,       3,       4,         NA,      "9",     "5",    NA,         NA,       NA,      NA,    NA,       NA,          NA,  "Biden +16",
                     "Emerson",   "12/6 - 12/9",     26,       22,       7,       9,         NA,       NA,      NA,    NA,         NA,       NA,      NA,    NA,       NA,          NA,   "Biden +4",
              "Harvard-Harris", "11/25 - 11/26",     28,       21,       5,       3,         NA,      "7",     "4",    NA,         NA,       NA,      NA,    NA,       NA,          NA,   "Biden +7",
              "Harvard-Harris", "11/25 - 11/26",     25,       15,       4,       2,         NA,      "9",     "3",    NA,         NA,       NA,      NA,    NA,       NA,          NA,  "Biden +10",
    "Politico/Morning Consult",   "11/7 - 11/9",     26,       19,       5,       4,         NA,      "8",     "3",    NA,        "1",       NA,     "1",    NA,       NA,         "1",   "Biden +7",
                         "CNN",   "10/4 - 10/7",     33,       13,       8,       9,         NA,      "4",     "5",    NA,        "1",       NA,      NA,    NA,       NA,         "1",  "Biden +20")
  

# export ------------------------------------------------------------------
write_csv(as.data.frame(RCPollData), paste0("data/",
  base::noquote(lubridate::today()),
          "-RCPollData.csv"))
